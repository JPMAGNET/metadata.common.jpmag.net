# metadata.jpmag.net
JPMAG.NET JAV scraper for KODI



JAV Movie scraper for KODI


first, install this, 
and after install https://github.com/JPMAGNET/metadata.jpmag.net.

Sign up, Login is http://jpmag.net

